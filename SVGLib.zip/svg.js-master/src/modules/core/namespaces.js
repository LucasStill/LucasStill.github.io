// Default namespaces
export const svg = 'http://www.w3.org/2000/svg'
export const html = 'http://www.w3.org/1999/xhtml'
export const xmlns = 'http://www.w3.org/2000/xmlns/'
export const xlink = 'http://www.w3.org/1999/xlink'
export const svgjs = 'http://svgjs.com/svgjs'
